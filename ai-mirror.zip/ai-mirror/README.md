# AI Mirror 2090

## Run locally
1. Install Node 18+. 2. Copy `.env.example` to `.env` and add your keys. 3. `node server.js`, open http://localhost:3000 in Chrome or Edge.

## Put it online (Render, free tier works)
1. Create a GitHub repo and upload this folder's files (`.env` is ignored, never upload keys).
2. On render.com: New > Web Service > connect the repo. Runtime Node, start command `node server.js`.
3. Under Environment add: ANTHROPIC_API_KEY, BFL_API_KEY, MIRROR_PASSWORD.
4. Deploy, then open your https://....onrender.com address. HTTPS is automatic, so mic, camera and location work.
Free instances sleep when idle and take about 30 seconds to wake.
