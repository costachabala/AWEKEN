// AI Mirror server: keeps your API keys private. No dependencies, Node 18+.
const http=require("http"),fs=require("fs"),path=require("path");
try{fs.readFileSync(path.join(__dirname,".env"),"utf8").split("\n").forEach(l=>{const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);if(m&&!process.env[m[1]])process.env[m[1]]=m[2].replace(/^["']|["']$/g,"")})}catch{}
const {ANTHROPIC_API_KEY:AK,BFL_API_KEY:BK,CLAUDE_MODEL="claude-sonnet-5-5",BFL_MODEL="flux-pro-1.1",PORT=3000}=process.env;
const send=(r,c,o)=>{r.writeHead(c,{"Content-Type":"application/json"});r.end(JSON.stringify(o))};
const body=q=>new Promise(r=>{let d="";q.on("data",c=>{d+=c;if(d.length>8e6)q.destroy()});q.on("end",()=>{try{r(JSON.parse(d||"{}"))}catch{r({})}})});
const desc=c=>c===0?"clear sky":c<4?"partly cloudy":c<50?"foggy":c<60?"drizzle":c<70?"rain":c<80?"snow":c<90?"rain showers":"thunderstorm";
const SYS=`You are MIRROR, a serene, confident AI stylist living in a smart mirror in the year 2090. You are expert in outfits, event dress codes (weddings, interviews, galas, dates, festivals, funerals, gym, travel), hairstyles, grooming, colour theory and fit. Use the live weather, time and place in Context. If a photo of the person is attached, use it tactfully (face shape, hair, skin tone, build). If no photo and a hairstyle needs face shape or hair type, ask one short question. Be warm, decisive and specific.
Reply with ONLY JSON: {"say":"spoken reply, max 50 words, no markdown","title":"2-4 word heading","items":["up to 5 short concrete lines like 'Top: navy linen shirt'"],"palette":["up to 5 hex colours"],"image":true or false,"image_prompt":"a detailed photographic prompt: subject, exact garments with colours and fabrics, hairstyle, pose, setting, lighting. No real people's names"}. Set image true when the user asks to see something or when giving a full outfit or hairstyle recommendation. For casual chat, items may be empty and palette [].`;
const routes={
 async "GET /api/weather"(q,s,u){const la=+u.searchParams.get("lat"),lo=+u.searchParams.get("lon");if(!isFinite(la)||!isFinite(lo))return send(s,400,{error:"bad location"});
  const j=await(await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${la}&longitude=${lo}&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1`)).json();
  send(s,200,{tz:j.timezone,temp:j.current.temperature_2m,feels:j.current.apparent_temperature,desc:desc(j.current.weather_code),wind:j.current.wind_speed_10m,high:j.daily.temperature_2m_max[0],low:j.daily.temperature_2m_min[0],rain:j.daily.precipitation_probability_max[0]})},
 async "POST /api/chat"(q,s){if(!AK)return send(s,500,{error:"ANTHROPIC_API_KEY missing in .env"});
  const {message,history=[],image,context=""}=await body(q);const c=[];
  if(image)c.push({type:"image",source:{type:"base64",media_type:"image/jpeg",data:image}});c.push({type:"text",text:message});
  const msgs=[...history.slice(-8).map(h=>({role:h.role,content:h.text})),{role:"user",content:c}];
  while(msgs.length>1&&msgs[0].role!=="user")msgs.shift();
  const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"content-type":"application/json","x-api-key":AK,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:CLAUDE_MODEL,max_tokens:900,system:SYS+"\n\nContext: "+context,messages:msgs})});
  const j=await r.json();if(!r.ok)return send(s,502,{error:j.error?.message||"AI error"});
  send(s,200,{text:j.content.map(x=>x.text||"").join("")})},
 async "POST /api/image"(q,s){if(!BK)return send(s,500,{error:"BFL_API_KEY missing in .env"});
  const {prompt=""}=await body(q);
  const a=await fetch("https://api.bfl.ai/v1/"+BFL_MODEL,{method:"POST",headers:{"x-key":BK,"content-type":"application/json",accept:"application/json"},body:JSON.stringify({prompt:"Photorealistic editorial fashion photograph, 85mm lens, soft natural light, ultra detailed, true-to-life skin and fabric texture. "+prompt,width:768,height:1024})});
  const aj=await a.json();if(!a.ok||!(aj.polling_url||aj.id))return send(s,502,{error:JSON.stringify(aj).slice(0,200)});
  const url=aj.polling_url||"https://api.bfl.ai/v1/get_result?id="+aj.id;
  for(let i=0;i<80;i++){await new Promise(r=>setTimeout(r,1500));
   const p=await(await fetch(url,{headers:{"x-key":BK,accept:"application/json"}})).json();
   if(p.status==="Ready"){const b=Buffer.from(await(await fetch(p.result.sample)).arrayBuffer());return send(s,200,{image:"data:image/jpeg;base64,"+b.toString("base64")})}
   if(/error|moderated|fail/i.test(p.status))return send(s,422,{error:p.status})}
  send(s,504,{error:"Image timed out"})}
};
const PW=process.env.MIRROR_PASSWORD,hits={};
const limited=(q,k,max)=>{const key=((q.headers["x-forwarded-for"]||q.socket.remoteAddress||"").split(",")[0].trim())+k,n=Date.now();hits[key]=(hits[key]||[]).filter(t=>n-t<6e4);if(hits[key].length>=max)return true;hits[key].push(n);return false};
const authed=q=>!PW||Buffer.from((q.headers.authorization||"").split(" ")[1]||"","base64").toString().split(":").slice(1).join(":")===PW;
http.createServer(async(q,s)=>{const u=new URL(q.url,"http://x");const h=routes[q.method+" "+u.pathname];
 if(!authed(q)){s.writeHead(401,{"WWW-Authenticate":'Basic realm="Mirror"'});return s.end("Password required")}
 if(h&&q.method==="POST"&&limited(q,u.pathname,u.pathname==="/api/image"?6:20))return send(s,429,{error:"Slow down a moment."});
 try{if(h)return await h(q,s,u);
  if(q.method==="GET"){s.writeHead(200,{"Content-Type":"text/html"});return s.end(fs.readFileSync(path.join(__dirname,"public/index.html")))}
  s.writeHead(404);s.end()}catch(e){send(s,500,{error:String(e.message||e)})}
}).listen(PORT,"0.0.0.0",()=>console.log("MIRROR awake → http://localhost:"+PORT));
